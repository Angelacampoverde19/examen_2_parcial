# examen_2_parcial_flutter

A new Flutter project.

## Getting Started
Este código Flutter utiliza el patrón Provider para gestionar el estado de las tareas. 
Donde la aplicación consta de varias pantallas: TaskListScreen muestra la lista de tareas, 
AddTaskScreen permite agregar nuevas tareas, y EditTaskScreen permite editar tareas existentes.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
